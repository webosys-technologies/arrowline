<?php 
  $this->load->view('layout/header');
  $user_session = $this->session->userdata('userRole');
  
  if(empty($user_session))
  {
    redirect('auth','refresh');
  }
  if(!in_array("manage_unit",$user_session)){
      redirect('auth','refresh');
  }

?>
<div class="content-wrapper">
    <div id="notifications" class="row no-print">
        <div class="col-md-12">
        </div>
    </div>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
            <div class="alert alert-info alert-dismissible">
              <button type="button" class="close" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-info"></i>Alert!</h4>
                Database Backup is not available in demo version
            </div>
        </div>
        <!-- /.col -->
        <div class="col-md-12">
          <div class="box box-default">
            <div class="box-body">
              <div class="row">
                <div class="col-md-10">
                  <div class="top-bar-title padding-bottom">
                    Database Backup
                    <!-- <?php echo $this->lang->line('lbl_unit_header');?> -->
                  </div>
                </div> 
                <div class="col-md-2">
                  <!-- <?php if(isset($user_session)){
                    if(in_array("add_unit",$user_session)){
                  ?> -->
                      <a href="#" class="btn btn-block btn-primary btn-flat"><i class="fa fa-cloud-download">&nbsp;</i>
                        Database Backup
                        <!-- <?php echo $this->lang->line('btn_unit_newunit');?> -->
                      </a>
                  <!-- <?php }} ?> -->
                </div>
              </div>
            </div>
          </div>

          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="indexdesc" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>
                      # Sr No.
                      <!-- <?php echo $this->lang->line('lbl_unit_name');?> -->
                  </th>
                  <th>
                      Name
                      <!-- <?php echo $this->lang->line('lbl_unit_abbr');?> -->
                  </th>
                  <th>
                    Date
                      <!-- <?php echo $this->lang->line('lbl_unit_action');?> -->
                  </th>
                  <th>
                    <!-- Action -->
                      <?php echo $this->lang->line('lbl_unit_action');?>
                  </th>
                </tr>
                </thead>
                <tbody>

                <?php foreach ($db as $row):?>
                  <tr>
                          <td><?php echo $row->id;?></td>
                          <td><?php echo $row->name;?></td>
                          <td><?php echo $row->date;?></td>
                          <td>
                              <!-- <?php if(isset($user_session)){
                                if(in_array("edit_unit",$user_session)){
                              ?> -->
                              <a title="Download Database" href="#" class="btn btn-xs btn-primary edit-unit" data-tt="tooltip"><span class="fa fa-cloud-download"></span></a> &nbsp;
                              <!-- <?php }} ?> -->


                              <!-- <?php if(isset($user_session)){
                                if(in_array("delete_unit",$user_session)){
                              ?> -->
                              <!--<a title="Delete" href="#<?php echo $row->id;?>" class="btn btn-xs btn-danger edit-unit" data-toggle="modal" data-target="" data-tt="tooltip"><span class="fa fa-remove"></span></a>--> &nbsp;
                              <!-- <?php }} ?> -->
                              
                            <div class="example-modal">
                            <div class="modal fade" id="<?php echo $row->id;?>">
                              <div class="modal-dialog">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span></button>
                                    <center><h4 class="modal-title">
                                        <!-- !!  Delete Units !! -->
                                        <?php echo $this->lang->line('lbl_unit_delete_modal');?>
                                        </h4></center>
                                  </div>
                                  <div class="modal-body">
                                    <p><h4><b> Are you sure to delete this Record !!
                                      &hellip;</b></h4></p>
                                  </div>
                                  <div class="modal-footer">
                                    
                                      <input type="hidden" name="branch_id1" value="<?php echo $row->id;?>">
                                      <button type="button" class="btn btn-default" data-dismiss="modal"><!-- Close -->
                                        <?php echo $this->lang->line('btn_modal_close');?>
                                      </button>
                                      <a href="<?php echo base_url();?>/hi/delete/<?php echo $row->id;?>" class="btn btn-danger" ><!-- Delete -->
                                        <?php echo $this->lang->line('btn_modal_delete');?>
                                      </a>
                                    
                                  </div>
                                </div>
                                <!-- /.modal-content -->
                              </div>
                              <!-- /.modal-dialog -->
                            </div>
                            <!-- /.modal -->
                          </div>
                          <!-- /.example-modal -->
               
                          </td>      
                  </tr>

                <?php endforeach;?>
                               
                  </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>

    <!-- /.content -->
</div>


<?php 
    $this->load->view('layout/footer');
?> 
